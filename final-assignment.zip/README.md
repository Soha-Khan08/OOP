RPG Adventure Game – README
How to Run the Game
Open the project folder in Codio or Python IDLE.

Make sure all the .py files (main game and unit tests) are in the same folder.

Open the file named main.py (or the main game file).

Click Run or press F5 to start the game.

Follow the on-screen instructions to create your character and play.

How to Run the Unit Tests
We used Python’s built-in unittest module for testing.

Steps to run tests:
Open the file called test_game.py (this is the file with all the unit tests).

Make sure it’s in the same folder as your main game code.

Click Run or press F5.

The tests will run automatically and show if anything is failing or working correctly.

Task Approach Summary
Here’s how I approached each part of the project:

I started by building basic classes like Character, Enemy, and Item.

I added a combat system where the player and enemy take turns.

Then I added inventory, items, and enemy drops.

I made different enemy types with different stats.

I included a crafting system, consumables, and a way to save/load the game using text files.

Finally, I created unit tests to make sure everything works properly.

New Features
Here are the new features I added to the game:

Multiple Enemy Types: Goblin and Orc, each with different HP and damage.

Combat Options: Player can attack, use items, defend, or flee.

Item Stats: Weapons increase attack damage.

Consumables: Health potions restore HP.

Inventory System: Shows what the player owns.

Enemy Drops: Enemies drop random items after battle.

Item Rarity & Drop Chances: Some items are more rare than others.

Crafting System: Combine items to make stronger weapons.

Save/Load Game: Progress can be saved and loaded from a file.

Unit Tests: Test core parts like combat, item use, and enemy drops.
Challenges and Solutions
During the development of the RPG game, I faced a few challenges:

1. Making the Combat Fair and Fun:
At first, the combat felt too hard or too easy. To fix this, I added some randomness to how much damage is done during attacks. I also gave the player options to defend or run away, which helped balance the gameplay.

2. Managing the Inventory:
It was tricky to keep track of what items the player has and how they are used. I solved this by using lists to store items and creating clear functions to add, remove, and use items from the inventory.

3. Handling Item Drops and Crafting:
At first, it was confusing to decide how enemies would drop items and how crafting would work. I used dictionaries and lists to control what enemies drop and made simple recipes for combining items.

4. Saving and Loading the Game:
I wanted the player to continue their game later, but I didn’t know how to save progress. I solved this by saving important data (like name, HP, and inventory) into a text file and reading it back when loading the game.

5. Writing Unit Tests:
It was new to me, but I learned how to test different parts of the game using Python’s unittest module. I tested things like attacking, using items, and checking enemy drops to make sure everything worked properly.

## How to Run the Game

### Requirements:
- Python 3.x installed

### Instructions:
1. Open a terminal or command prompt
2. Navigate to the folder containing the game file
3. Run the game using:

```bash
python rpg_game.py

