from item import Item

class Inventory:
    def __init__(self):
        self.items = []

    def add_item(self, item):
        self.items.append(item)

    def show_inventory(self):
        print("Inventory:")
        for item in self.items:
            print(f"- {item}")

    def use_item(self, item_name, character):
        for item in self.items:
            if item.name == item_name:
                character.hp += item.defense  # Item heals or boosts defense
                print(f"{character.name} uses {item.name} and gains {item.defense} defense!")
                self.items.remove(item)
                return
        print("Item not found.")
