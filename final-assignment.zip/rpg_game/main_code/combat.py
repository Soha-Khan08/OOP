import random
from main_code.enemy import Enemy
from main_code.item import Item

def combat(player, enemy):
    print(f"\nA wild {enemy.name} appears!")
    while player.is_alive() and enemy.is_alive():
        print("\nYour turn:")
        print("1. Attack")
        print("2. Use Item")
        print("3. Show Inventory")
        print("4. Flee")
        action = input("Choose your action: ")

        if action == '1':
            player.attack(enemy)
        elif action == '2':
            player.show_inventory()
            idx = int(input("Enter item number to use: ")) - 1
            player.use_item(idx)
            continue
        elif action == '3':
            player.show_inventory()
            continue
        elif action == '4':
            if random.random() < 0.5:
                print("You successfully fled!")
                return
            else:
                print("Failed to flee!")
        else:
            print("Invalid action.")
            continue

        if enemy.is_alive():
            enemy.attack(player)

    if player.is_alive():
        print(f"\nYou defeated the {enemy.name}!")
        drop_item = random.choices(enemy.drops, weights=[item[1] for item in enemy.drops])[0][0]
        print(f"Enemy dropped: {drop_item.name}")
        player.add_item(drop_item)
    else:
        print("\nYou have been defeated.")