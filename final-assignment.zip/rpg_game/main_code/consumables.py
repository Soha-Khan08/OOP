class Consumable(Item):
    def __init__(self, name, description, hp_restore=0, attack_boost=0):
        super().__init__(name, description)
        self.hp_restore = hp_restore
        self.attack_boost = attack_boost

    def use(self, character):
        character.hp += self.hp_restore
        print(f"{character.name} used {self.name} and restored {self.hp_restore} HP!")
