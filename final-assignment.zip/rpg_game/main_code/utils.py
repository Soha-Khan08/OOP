import random

def random_chance(probability):
    """Returns True if the random chance is met, else False"""
    return random.random() < probability
