import unittest
from character import Character
from enemy import Enemy
from item import Item
from combat import combat
from consumables import Consumable
from save_load import save_game, load_game
import random

class TestRPGGame(unittest.TestCase):

    def test_character_creation(self):
        player = Character("Hero", 100)
        self.assertEqual(player.name, "Hero")
        self.assertEqual(player.hp, 100)
        self.assertTrue(player.is_alive())

    def test_enemy_creation(self):
        enemy = Enemy("Goblin", 50)
        self.assertEqual(enemy.name, "Goblin")
        self.assertEqual(enemy.hp, 50)
        self.assertTrue(enemy.is_alive())

    def test_attack(self):
        player = Character("Hero", 100)
        enemy = Enemy("Goblin", 50)
        player.attack(enemy)
        self.assertTrue(enemy.hp < 50)  # Check if enemy's HP has decreased

    def test_item_usage(self):
        item = Item("Healing Potion", "Restores 20 HP", 0, 0)
        player = Character("Hero", 50)
        player.add_item(item)
        self.assertIn(item, player.inventory)
        player.hp += 20  # Simulate using the item to restore HP
        self.assertEqual(player.hp, 70)

    def test_inventory(self):
        player = Character("Hero", 100)
        item1 = Item("Wooden Sword", "A basic wooden sword.", attack=5)
        item2 = Item("Healing Potion", "Restores 20 HP", 0, 0)
        player.add_item(item1)
        player.add_item(item2)

        self.assertEqual(len(player.inventory), 2)  # Ensure two items were added
        player.show_inventory()  # Ensure inventory prints correctly

    def test_combat(self):
        player = Character("Hero", 100)
        enemy = Enemy("Goblin", 50)
        combat(player, enemy)
        self.assertTrue(player.is_alive() or not enemy.is_alive())  # Either player survives or enemy is defeated

    def test_consumable_usage(self):
        consumable = Consumable("Health Potion", "Restores 30 HP", hp_restore=30)
        player = Character("Hero", 50)
        player.add_item(consumable)
        self.assertEqual(player.hp, 50)
        consumable.use(player)  # Simulate using consumable
        self.assertEqual(player.hp, 80)

    def test_save_load_game(self):
        player = Character("Hero", 100)
        save_game(player, "test_save.pkl")
        loaded_player = load_game("test_save.pkl")
        self.assertEqual(player.name, loaded_player.name)
        self.assertEqual(player.hp, loaded_player.hp)

    def test_random_chance(self):
        # Test the random_chance function with 50% probability
        success = sum(random_chance(0.5) for _ in range(100))  # Should be close to 50
        self.assertTrue(40 <= success <= 60)  # Allow some tolerance for randomness

    def test_item_crafting(self):
        # Assuming a crafting system exists where combining items creates a new one
        item1 = Item("Wooden Sword", "A basic wooden sword.", attack=5)
        item2 = Item("Iron Ore", "A chunk of iron.", attack=0)
        crafted_item = Crafting.combine_items(item1, item2)
        self.assertIsNotNone(crafted_item)
        self.assertEqual(crafted_item.name, "Iron Sword")
        self.assertEqual(crafted_item.attack, 15)

if __name__ == "__main__":
    unittest.main()
