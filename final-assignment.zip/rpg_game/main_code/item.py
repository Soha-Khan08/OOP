class Item:
    def __init__(self, name, description="", attack=0, defense=0, is_consumable=False, healing=0):
        self.name = name
        self.description = description
        self.attack = attack
        self.defense = defense
        self.is_consumable = is_consumable
        self.healing = healing

    def __str__(self):
        return f"{self.name}: {self.description}"

