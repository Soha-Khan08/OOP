import random

class Player:
    def __init__(self, name, health, attack, defense):
        self.name = name
        self.health = health
        self.attack = attack
        self.defense = defense

    def attack_enemy(self, enemy):
        damage = self.attack - enemy.defense
        damage = max(damage, 0)  # Make sure damage is not negative
        enemy.health -= damage
        print(f"{self.name} attacks {enemy.name}!")
        print(f"{enemy.name}'s Health: {enemy.health}")

    def use_item(self, item):
        if item.is_consumable:
            self.health += item.healing
            self.health = min(self.health, 100)  # Ensure health does not exceed max health
            print(f"{self.name} uses {item.name}. {self.name}'s Health: {self.health}")

    def level_up(self):
        self.attack += 5
        self.defense += 3
        print(f"{self.name} levels up!")
        print(f"{self.name}: Health = {self.health}, Attack = {self.attack}, Defense = {self.defense}")

class Enemy:
    def __init__(self, name, health, attack, defense):
        self.name = name
        self.health = health
        self.attack = attack
        self.defense = defense

    def attack_player(self, player):
        damage = self.attack - player.defense
        damage = max(damage, 0)  # Ensure damage is not negative
        player.health -= damage
        print(f"{self.name} attacks {player.name}!")
        print(f"{player.name}'s Health: {player.health}")
