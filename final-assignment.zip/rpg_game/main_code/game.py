from main_code.character import Character
from main_code.item import Item
from main_code.enemy import Enemy
from main_code.combat import combat
from main_code.save_load import save_game, load_game


def main_menu():
    while True:
        print("\n=== RPG Adventure ===")
        print("1. Start New Game")
        print("2. Load Game")
        print("3. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            name = input("Enter your character's name: ")
            player = Character(name)
            player.add_item(Item("Wooden Sword", "A basic wooden sword.", attack=5))
            enemy = Enemy("Goblin", 40, (5, 10), [(Item("Healing Potion", "Heals 20 HP", is_consumable=True, healing=20), 1.0)])
            combat(player, enemy)
            save_game(player)
        elif choice == '2':
            player = load_game()
            if player:
                enemy = Enemy("Orc", 60, (8, 12), [(Item("Iron Sword", "A stronger sword.", attack=10), 1.0)])
                combat(player, enemy)
                save_game(player)
        elif choice == '3':
            print("Goodbye!")
            break
        else:
            print("Invalid choice.")