from character import Player, Enemy
from item import Item

# Create player
player = Player(name="Hero", health=100, attack=10, defense=5)

# Create some items
health_potion = Item(name="Health Potion", description="Restores 50 HP", healing=50, is_consumable=True)
attack_potion = Item(name="Attack Potion", description="Increases Attack by 5 for 3 turns", attack=5, is_consumable=True)
defense_potion = Item(name="Defense Potion", description="Increases Defense by 5 for 3 turns", defense=5, is_consumable=True)

# Add items to the player's inventory
player_inventory = [health_potion, attack_potion, defense_potion]

# Create an enemy
goblin = Enemy(name="Goblin", health=50, attack=8, defense=3)

def game():
    print("Welcome to the game, Hero!\n")

    while goblin.health > 0 and player.health > 0:
        print("\n--- Combat ---")
        print(f"{player.name}: Health = {player.health}, Attack = {player.attack}, Defense = {player.defense}")
        print(f"{goblin.name}: Health = {goblin.health}, Attack = {goblin.attack}, Defense = {goblin.defense}")
        
        print("\nChoose an action:")
        print("1. Attack")
        print("2. Use Item")
        print("3. Flee")
        action = input("Enter your action: ")

        if action == "1":
            player.attack_enemy(goblin)
            if goblin.health > 0:
                goblin.attack_player(player)
        elif action == "2":
            print("\nChoose an item to use:")
            for index, item in enumerate(player_inventory):
                print(f"{index + 1}. {item.name} - {item.description}")
            item_choice = int(input("\nEnter the number of the item to use: ")) - 1
            if 0 <= item_choice < len(player_inventory):
                item = player_inventory[item_choice]
                player.use_item(item)
                if goblin.health > 0:
                    goblin.attack_player(player)
            else:
                print("Invalid choice!")
        elif action == "3":
            print(f"{player.name} flees from the battle!")
            break
        else:
            print("Invalid action!")

    if player.health <= 0:
        print(f"{player.name} has been defeated...")
    elif goblin.health <= 0:
        print(f"{goblin.name} has been defeated!")

if __name__ == "__main__":
    game()
