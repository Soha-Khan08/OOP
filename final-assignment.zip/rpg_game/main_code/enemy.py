import random

class Enemy:
    def __init__(self, name, hp, damage_range, drops):
        self.name = name
        self.hp = hp
        self.damage_range = damage_range
        self.drops = drops

    def is_alive(self):
        return self.hp > 0

    def attack(self, character):
        damage = random.randint(*self.damage_range)
        print(f"{self.name} attacks {character.name} for {damage} damage!")
        character.take_damage(damage)

    def take_damage(self, damage):
        self.hp -= damage
        print(f"{self.name} takes {damage} damage! (HP: {self.hp})")
