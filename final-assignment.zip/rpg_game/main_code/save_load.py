import json
import os

def save_game(player, filename="savefile.json"):
    data = {
        "name": player.name,
        "hp": player.hp,
        "inventory": [vars(item) for item in player.inventory]
    }
    with open(filename, 'w') as f:
        json.dump(data, f)

def load_game(filename="savefile.json"):
    from main_code.character import Character
    from main_code.item import Item

    if not os.path.exists(filename):
        print("No save file found.")
        return None

    with open(filename, 'r') as f:
        data = json.load(f)

    player = Character(data["name"], data["hp"])
    for item_data in data["inventory"]:
        item = Item(**item_data)
        player.add_item(item)

    return player

