class Crafting:
    @staticmethod
    def combine_items(item1, item2):
        if item1.name == "Wooden Sword" and item2.name == "Iron Ore":
            new_item = Item("Iron Sword", "A stronger sword.", attack=15)
            print("Crafted: Iron Sword!")
            return new_item
        print("Crafting failed.")
        return None
