from item import Item

potion = Item("Health Potion", "potion", effect=25)
herb = Item("Herb", "material")
water = Item("Water", "material")

recipe_book = {
    ("Herb", "Water"): potion
}
