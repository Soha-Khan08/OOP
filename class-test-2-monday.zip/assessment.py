import random

# Task 1: Base Class Definition for Energy Producers
class PowerPlant:
    def __init__(self, name, capacity):
        self.name = name
        self.capacity = capacity
        self.current_output = 0.0

    def get_name(self):
        return self.name

    def get_current_output(self):
        return self.current_output

    def get_remaining_capacity(self):
        return self.capacity - self.current_output

    def add_output(self, amount):
        if self.current_output + amount > self.capacity:
            return False
        self.current_output += amount
        return True


# Task 2: Managing PowerPlant Output
class SolarPlant(PowerPlant):
    def __init__(self, name, capacity):
        super().__init__(name, capacity)
        self.sunlight_intensity = 0.0

    def update_output(self):
        self.current_output = min(self.capacity, self.capacity * (self.sunlight_intensity / 100.0))


class WindPlant(PowerPlant):
    def __init__(self, name, capacity):
        super().__init__(name, capacity)
        self.wind_speed = 0.0

    def update_output(self):
        self.current_output = min(self.capacity, self.capacity * (self.wind_speed / 30.0))


# Task 3: Specialised Producer Classes (Inheritance)
class SolarPlant(PowerPlant):
    def __init__(self, name, capacity):
        super().__init__(name, capacity)
        self.sunlight_intensity = 0.0

    def update_output(self):
        self.current_output = min(self.capacity, self.capacity * (self.sunlight_intensity / 100.0))


class WindPlant(PowerPlant):
    def __init__(self, name, capacity):
        super().__init__(name, capacity)
        self.wind_speed = 0.0

    def update_output(self):
        self.current_output = min(self.capacity, self.capacity * (self.wind_speed / 30.0))


# Task 4: Defining the Consumer Class
class EnergyConsumer:
    def __init__(self, name, base_demand):
        self.name = name
        self.base_demand = base_demand
        self.current_demand = base_demand

    def update_demand(self):
        if random.random() < 0.5:
            self.current_demand = self.base_demand * 0.95
        else:
            self.current_demand = self.base_demand * 1.05


# Task 5: Randomising Environmental Conditions
class SolarPlant(PowerPlant):
    def __init__(self, name, capacity):
        super().__init__(name, capacity)
        self.sunlight_intensity = 0.0

    def randomise_sunlight(self):
        self.sunlight_intensity = random.uniform(50, 100)

    def update_output(self):
        self.current_output = min(self.capacity, self.capacity * (self.sunlight_intensity / 100.0))


class WindPlant(PowerPlant):
    def __init__(self, name, capacity):
        super().__init__(name, capacity)
        self.wind_speed = 0.0

    def randomise_wind(self):
        self.wind_speed = random.uniform(0, 30)

    def update_output(self):
        self.current_output = min(self.capacity, self.capacity * (self.wind_speed / 30.0))


# Task 6: Aggregating Producers and Consumers in the Energy Grid
class EnergyGrid:
    def __init__(self):
        self.plants = []
        self.consumers = []

    def add_plant(self, plant):
        self.plants.append(plant)

    def remove_plant(self, plant_name):
        self.plants = [plant for plant in self.plants if plant.name != plant_name]

    def add_consumer(self, consumer):
        self.consumers.append(consumer)

    def remove_consumer(self, consumer_name):
        self.consumers = [consumer for consumer in self.consumers if consumer.name != consumer_name]

    def total_current_output(self):
        return sum(plant.get_current_output() for plant in self.plants)

    def total_capacity(self):
        return sum(plant.capacity for plant in self.plants)

    def total_demand(self):
        return sum(consumer.current_demand for consumer in self.consumers)

    def simulate_grid_day(self):
        for plant in self.plants:
            if isinstance(plant, SolarPlant):
                plant.randomise_sunlight()
            elif isinstance(plant, WindPlant):
                plant.randomise_wind()
            plant.update_output()

        for consumer in self.consumers:
            consumer.update_demand()

        total_supply = self.total_current_output()
        total_demand = self.total_demand()

        print(f"Total Supply: {total_supply} MW, Total Demand: {total_demand} MW.")
        if total_supply >= total_demand:
            print("The grid meets the demand.")
        else:
            print("Insufficient supply! Some consumers may be affected.")


# Testing
if __name__ == "__main__":
    # Task 1: Test PowerPlant and its methods
    print("Testing Task 1: PowerPlant")
    plant = PowerPlant("Generic Plant", 100)
    print(f"Name: {plant.get_name()}")
    print(f"Capacity: {plant.capacity} MW")
    print(f"Current Output: {plant.get_current_output()} MW")
    print(f"Remaining Capacity: {plant.get_remaining_capacity()} MW")
    print(f"Add Output (50 MW): {plant.add_output(50)}")
    print(f"Remaining Capacity after Output: {plant.get_remaining_capacity()} MW")

  # Task 2: Test Solar and Wind Plants' Output Update
    print("\nTesting Task 2: Solar and Wind Plants Update Output")
    solar = SolarPlant("Sunny", 100.0)
    wind = WindPlant("Windy", 120.0)
    solar.sunlight_intensity = 80  # 80% sunlight
    wind.wind_speed = 20  # 20 m/s wind speed

    solar.update_output()
    wind.update_output()

    print(f"Solar Output: {solar.get_current_output()} MW")
    print(f"Wind Output: {wind.get_current_output()} MW")

    # Task 3: Test Consumer Demand Update
    print("\nTesting Task 3: Consumer Demand Update")
    consumer = EnergyConsumer("House1", 10.0)
    print(f"Initial Demand: {consumer.current_demand} MW")
    consumer.update_demand()
    print(f"Updated Demand: {consumer.current_demand} MW")

    # Task 4: Test Random Environmental Conditions (Sunlight and Wind)
    print("\nTesting Task 4: Random Environmental Conditions")
    solar.randomise_sunlight()
    wind.randomise_wind()

    print(f"Random Solar Sunlight Intensity: {solar.sunlight_intensity}%")
    print(f"Random Wind Speed: {wind.wind_speed} m/s")

    # Task 5: Test EnergyGrid and Adding Producers and Consumers
    print("\nTesting Task 5: EnergyGrid")
    grid = EnergyGrid()
    grid.add_plant(solar)
    grid.add_plant(wind)
    grid.add_consumer(consumer)

    print(f"Total Plants: {len(grid.plants)}")
    print(f"Total Consumers: {len(grid.consumers)}")

    # Task 6: Simulate Grid Day and Check if Supply Meets Demand
    print("\nTesting Task 6: Simulate Grid Day")
    grid.simulate_grid_day()
