# Task 1: Basic Class Definitions

class Song:
    def __init__(self, title, required_rehearsals=3):
        self.title = title
        self.required_rehearsals = required_rehearsals
        self.completed_rehearsals = 0

class Band:
    def __init__(self, name, max_songs=5):
        self.name = name
        self.planned_songs = []
        self.max_songs = max_songs

class RecordingSession:
    def __init__(self, studio_name):
        self.studio_name = studio_name

class LivePerformance:
    def __init__(self, event_name):
        self.event_name = event_name

# Test A1
song = Song("Gentle Breeze")
result = (song.title, song.required_rehearsals, song.completed_rehearsals)
print(result)  # Expected: ("Gentle Breeze", 3, 0)

# Test A2
band = Band("The Rollers")
result = (band.name, band.planned_songs, band.max_songs)
print(result)  # Expected: ("The Rollers", [], 5)


# Task 2: Song Rehearsal functions

class Song:
    def __init__(self, title, required_rehearsals=3):
        self.title = title
        self.required_rehearsals = required_rehearsals
        self.completed_rehearsals = 0

    def rehearse(self):
        self.completed_rehearsals += 1

    def get_rehearsals(self):
        return self.completed_rehearsals

    def is_rehearsed(self):
        return self.get_rehearsals() >= self.required_rehearsals

# Test B1
track = Song("Morning Light", required_rehearsals=2)
track.rehearse()
track.rehearse()
result = (track.get_rehearsals(), track.required_rehearsals, track.is_rehearsed())
print(result)  # Expected Output: (2, 2, True)

# Test B2
track = Song("Nocturne", required_rehearsals=2)
initial = track.get_rehearsals()  # Expect 0
track.rehearse()
track.rehearse()
result = (track.get_rehearsals(), track.is_rehearsed())
print(result)  # Expected Output: (2, True)


# Task 3: Band Management and Rehearsals

class Band:
    def __init__(self, name, max_songs=5):
        self.name = name
        self.planned_songs = []
        self.max_songs = max_songs

    def add_song(self, song):
        if len(self.planned_songs) < self.max_songs:
            self.planned_songs.append(song)

    def rehearse_song(self, song_title):
        for song in self.planned_songs:
            if song.title == song_title:
                song.rehearse()

    def rehearse_all(self):
        for song in self.planned_songs:
            song.rehearse()

    def is_ready(self):
        return all(song.is_rehearsed() for song in self.planned_songs)

# Test C1
band = Band("Acoustics", max_songs=2)
song1 = Song("Gentle Breeze", required_rehearsals=2)
band.add_song(song1)
song2 = Song("Morning Light", required_rehearsals=3)
band.add_song(song2)

band.rehearse_song("Gentle Breeze")
band.rehearse_song("Gentle Breeze")  # "Gentle Breeze" now has 2 rehearsals

band.rehearse_song("Morning Light")
band.rehearse_song("Morning Light")
band.rehearse_song("Morning Light")  # "Morning Light" now has 3 rehearsals

result = band.is_ready()
print(result)  # Expected Output: True

# Test C2
band = Band("Overachievers", max_songs=1)
songA = Song("Final Countdown")
songB = Song("Extra Song")
band.add_song(songA)
band.add_song(songB)  # Should be ignored because max_songs is 1
result = len(band.planned_songs)
print(result)  # Expected Output: 1


# Task 4: Band Jam Session

class Band:
    def __init__(self, name, max_songs=5):
        self.name = name
        self.planned_songs = []
        self.max_songs = max_songs

    def add_song(self, song):
        if len(self.planned_songs) < self.max_songs:
            self.planned_songs.append(song)

    def rehearse_song(self, song_title):
        for song in self.planned_songs:
            if song.title == song_title:
                song.rehearse()

    def rehearse_all(self):
        for song in self.planned_songs:
            song.rehearse()

    def is_ready(self):
        return all(song.is_rehearsed() for song in self.planned_songs)

    def jam_session(self):
        for song in self.planned_songs:
            song.rehearse()

# Test D1
band = Band("Jam Masters", max_songs=3)
song1 = Song("Easy Ride", required_rehearsals=2)
band.add_song(song1)
song2 = Song("Slow Groove", required_rehearsals=3)
band.add_song(song2)
song3 = Song("Hot Beat", required_rehearsals=2)
band.add_song(song3)

band.jam_session()

result1 = song1.get_rehearsals()  # Expected: 1
result2 = song2.get_rehearsals()  # Expected: 1
result3 = song3.get_rehearsals()  # Expected: 1

print(result1)
print(result2)
print(result3)


# Task 5: Recording Session

class RecordingSession:
    def __init__(self, studio_name):
        self.studio_name = studio_name

    def record(self, band):
        return [song.title for song in band.planned_songs if song.is_rehearsed()]

# Test E1
band = Band("Sound Wizards", max_songs=3)
song1 = Song("Magic Tune", required_rehearsals=2)
band.add_song(song1)
song2 = Song("Mystery Beat", required_rehearsals=3)
band.add_song(song2)

band.rehearse_song("Magic Tune")
band.rehearse_song("Magic Tune")  # "Magic Tune" is now fully rehearsed

band.rehearse_song("Mystery Beat")
band.rehearse_song("Mystery Beat")  # "Mystery Beat" now has 2 rehearsals, not enough

session = RecordingSession("Studio X")
result = session.record(band)
print(result)  # Expected Output: ["Magic Tune"]


# Task 6: Live Performance Simulation

class LivePerformance:
    def __init__(self, event_name):
        self.event_name = event_name

    def perform(self, band):
        ratings = {}
        performance_score = 0
        fully_rehearsed_songs = [song for song in band.planned_songs if song.is_rehearsed()]
        
        for song in fully_rehearsed_songs:
            extra = song.completed_rehearsals - song.required_rehearsals
            rating = 5 + extra
            ratings[song.title] = rating
            performance_score += rating

        if len(fully_rehearsed_songs) > 2:
            for song in ratings:
                ratings[song] += 2  # Bonus points for more than 2 fully rehearsed songs
                performance_score += 2

        return ratings, performance_score

# Test F1
band = Band("Stage Stars", max_songs=3)
song1 = Song("Opening Act", required_rehearsals=2)
band.add_song(song1)
song2 = Song("Main Event", required_rehearsals=3)
band.add_song(song2)
song3 = Song("Encore", required_rehearsals=2)
band.add_song(song3)

band.rehearse_song("Opening Act")
band.rehearse_song("Opening Act")  # Opening Act: 2 rehearsals, extra = 0

band.rehearse_song("Main Event")
band.rehearse_song("Main Event")
band.rehearse_song("Main Event")   # Main Event: 3 rehearsals, extra = 0

band.rehearse_song("Encore")
band.rehearse_song("Encore")
band.rehearse_song("Encore")       # Encore: 3 rehearsals, extra = 1

performance = LivePerformance("Rock Night")
result = performance.perform(band)
print(result)  # Expected Output: ({'Opening Act': 7, 'Main Event': 7, 'Encore': 8}, 22)
