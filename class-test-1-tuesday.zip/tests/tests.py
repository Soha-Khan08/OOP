import sys
import io
import contextlib
from functools import wraps
import unittest.mock
from custom_html_unittest import StyledTestCase, run_tests

sys.path.append("/home/codio/workspace/")

try:
    from assessment import Song
except ImportError:
    Song = None

try:
    from assessment import Band
except ImportError:
    Band = None

try:
    from assessment import RecordingSession
except ImportError:
    RecordingSession = None

try:
    from assessment import LivePerformance
except ImportError:
    LivePerformance = None


def suppress_print(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        with contextlib.redirect_stdout(io.StringIO()):
            return func(*args, **kwargs)
    return wrapper

class TestBandConcertAssignment(StyledTestCase):
    ## Task 1: Basic Class Definitions
    def test_song_initial_attributes(self):
        if Song is None:
            self.fail("Song class not found.")
        song = Song("Gentle Breeze")
        reasoning_dict = {
            'pass': "Correct! Song's title, required rehearsals, and completed rehearsals are set properly.",
            'fail': "Incorrect. Song's attributes are not set as expected.",
            'error': "An error occurred while testing song initial attributes."
        }
        self.correct_solution = ("Gentle Breeze", 3, 0)
        student_solution = (song.title, song.required_rehearsals, song.completed_rehearsals)
        self.store_test_result(student_solution, self.correct_solution, reasoning_dict)
        self.assertEqual(student_solution, self.correct_solution)

    def test_band_initial_attributes(self):
        if Band is None:
            self.fail("Band class not found.")
        band = Band("The Rollers")
        reasoning_dict = {
            'pass': "Correct! Band's name, planned songs, and max songs are initialized correctly.",
            'fail': "Incorrect. Band's attributes are not set as expected.",
            'error': "An error occurred while testing band initial attributes."
        }
        self.correct_solution = ("The Rollers", [], 5)
        student_solution = (band.name, band.planned_songs, band.max_songs)
        self.store_test_result(student_solution, self.correct_solution, reasoning_dict)
        self.assertEqual(student_solution, self.correct_solution)

    ## Task 2: Song Rehearsal Methods
    def test_song_rehearse_methods_B1(self):
        if Song is None:
            self.fail("Song class not found.")
        track = Song("Morning Light", required_rehearsals=2)
        track.rehearse()
        track.rehearse()
        reasoning_dict = {
            'pass': "Correct! Song rehearsal count is updated and fully rehearsed as expected.",
            'fail': "Incorrect. Song rehearsal methods are not working as expected.",
            'error': "An error occurred while testing song rehearsal methods."
        }
        self.correct_solution = (2, 2, True)
        student_solution = (track.get_rehearsals(), track.required_rehearsals, track.is_rehearsed())
        self.store_test_result(student_solution, self.correct_solution, reasoning_dict)
        self.assertEqual(student_solution, self.correct_solution)

    def test_song_rehearse_methods_B2(self):
        if Song is None:
            self.fail("Song class not found.")
        track = Song("Nocturne", required_rehearsals=2)
        initial = track.get_rehearsals()  # Expect 0
        track.rehearse()
        track.rehearse()
        reasoning_dict = {
            'pass': "Correct! Song rehearsal count and is_rehearsed() status are correct.",
            'fail': "Incorrect. Song rehearsal methods did not update as expected.",
            'error': "An error occurred while testing song rehearsal methods."
        }
        self.correct_solution = (2, True)
        student_solution = (track.get_rehearsals(), track.is_rehearsed())
        self.store_test_result(student_solution, self.correct_solution, reasoning_dict)
        self.assertEqual(student_solution, self.correct_solution)

    ## Task 3: Band Management and Rehearsals
    def test_band_management_C1(self):
        if Band is None or Song is None:
            self.fail("Required classes not found.")
        band = Band("Acoustics", max_songs=2)
        song1 = Song("Gentle Breeze", required_rehearsals=2)
        band.add_song(song1)
        song2 = Song("Morning Light", required_rehearsals=3)
        band.add_song(song2)
        # Rehearse via band
        band.rehearse_song("Gentle Breeze")
        band.rehearse_song("Gentle Breeze")  # now 2 rehearsals
        band.rehearse_song("Morning Light")
        band.rehearse_song("Morning Light")
        band.rehearse_song("Morning Light")   # now 3 rehearsals
        reasoning_dict = {
            'pass': "Correct! Band is ready when all songs are fully rehearsed.",
            'fail': "Incorrect. Band readiness is not determined correctly.",
            'error': "An error occurred while testing band rehearsal management."
        }
        self.correct_solution = True
        student_solution = band.is_ready()
        self.store_test_result(student_solution, self.correct_solution, reasoning_dict)
        self.assertEqual(student_solution, self.correct_solution)

    def test_band_management_C2(self):
        if Band is None or Song is None:
            self.fail("Required classes not found.")
        band = Band("Overachievers", max_songs=1)
        songA = Song("Final Countdown")
        songB = Song("Extra Song")
        band.add_song(songA)
        band.add_song(songB)  # Should be ignored due to max_songs limit
        reasoning_dict = {
            'pass': "Correct! Band does not exceed the maximum number of songs.",
            'fail': "Incorrect. Band accepted more songs than allowed.",
            'error': "An error occurred while testing band song limit."
        }
        self.correct_solution = 1
        student_solution = len(band.planned_songs)
        self.store_test_result(student_solution, self.correct_solution, reasoning_dict)
        self.assertEqual(student_solution, self.correct_solution)

    def test_band_jam_session_increments(self):
        """
        This test verifies that calling jam_session() causes each song in the band's
        planned_songs to have its rehearsal count incremented by one.
        The function's return value is ignored.
        """
        if Band is None or Song is None:
            self.fail("Required classes not found.")
        band = Band("Jam Masters", max_songs=3)
        song1 = Song("Easy Ride", required_rehearsals=2)
        band.add_song(song1)
        song2 = Song("Slow Groove", required_rehearsals=3)
        band.add_song(song2)
        song3 = Song("Hot Beat", required_rehearsals=2)
        band.add_song(song3)
        
        # Record initial rehearsal counts (expected to be 0 for each song)
        initial_counts = []
        for song in band.planned_songs:
            initial_counts.append(song.get_rehearsals())
        
        # Call jam_session() to simulate a round of rehearsals
        ret_val = band.jam_session()
        
        # Check that each song's rehearsal count increased by 1
        new_counts = []
        for song in band.planned_songs:
            new_counts.append(song.get_rehearsals())
        
        reasoning_dict = {
            'pass': "Correct! All songs' rehearsal counts were incremented by one after the jam session.",
            'fail': "Incorrect. The jam session did not increment each song's rehearsal count as expected.",
            'error': "An error occurred while testing the jam_session() side effects."
        }
        
        expected_counts = [count + 1 for count in initial_counts]
        self.store_test_result(new_counts, expected_counts, reasoning_dict)
        self.assertEqual(new_counts, expected_counts)

    ## Task 5: Recording Session
    def test_recording_session_E1(self):
        if RecordingSession is None or Band is None or Song is None:
            self.skipTest("RecordingSession, Band, or Song class not implemented.")
        band = Band("Sound Wizards", max_songs=3)
        song1 = Song("Magic Tune", required_rehearsals=2)
        band.add_song(song1)
        song2 = Song("Mystery Beat", required_rehearsals=3)
        band.add_song(song2)
        band.rehearse_song("Magic Tune")
        band.rehearse_song("Magic Tune")  # Magic Tune fully rehearsed
        band.rehearse_song("Mystery Beat")
        band.rehearse_song("Mystery Beat")  # Mystery Beat not fully rehearsed (2/3)
        session = RecordingSession("Studio X")
        reasoning_dict = {
            'pass': "Correct! RecordingSession records only fully rehearsed songs.",
            'fail': "Incorrect. RecordingSession did not record the expected songs.",
            'error': "An error occurred while testing RecordingSession."
        }
        self.correct_solution = ["Magic Tune"]
        student_solution = session.record(band)
        self.store_test_result(student_solution, self.correct_solution, reasoning_dict)
        self.assertEqual(student_solution, self.correct_solution)

    ## Task 6: Live Performance Simulation
    def test_live_performance_F1(self):
        if LivePerformance is None or Band is None or Song is None:
            self.skipTest("LivePerformance, Band, or Song class not implemented.")
        band = Band("Stage Stars", max_songs=3)
        song1 = Song("Opening Act", required_rehearsals=2)
        band.add_song(song1)
        song2 = Song("Main Event", required_rehearsals=3)
        band.add_song(song2)
        song3 = Song("Encore", required_rehearsals=2)
        band.add_song(song3)
        # Rehearse songs via band:
        band.rehearse_song("Opening Act")
        band.rehearse_song("Opening Act")  # 2 rehearsals -> extra = 0, base = 5
        band.rehearse_song("Main Event")
        band.rehearse_song("Main Event")
        band.rehearse_song("Main Event")   # 3 rehearsals -> extra = 0, base = 5
        band.rehearse_song("Encore")
        band.rehearse_song("Encore")
        band.rehearse_song("Encore")       # 3 rehearsals -> extra = 1, base = 6
        performance = LivePerformance("Rock Night")
        reasoning_dict = {
            'pass': "Correct! LivePerformance calculates ratings and overall score correctly.",
            'fail': "Incorrect. LivePerformance ratings are not as expected.",
            'error': "An error occurred while testing LivePerformance."
        }
        # With more than 2 fully rehearsed songs, add bonus +2 to each song.
        # "Opening Act": 5+0=5+2=7, "Main Event": 5+0=5+2=7, "Encore": 5+1=6+2=8.
        # Overall score = 7 + 7 + 8 = 22.
        self.correct_solution = ({'Opening Act': 7, 'Main Event': 7, 'Encore': 8}, 22)
        student_solution = performance.perform(band)
        self.store_test_result(student_solution, self.correct_solution, reasoning_dict)
        self.assertEqual(student_solution, self.correct_solution)

if __name__ == '__main__':
    run_tests(TestBandConcertAssignment)
