import unittest
import html
import traceback
import sys
import io
import contextlib
from functools import wraps

def suppress_print(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Redirect stdout to an in-memory stream (effectively suppressing print)
        with contextlib.redirect_stdout(io.StringIO()):
            return func(*args, **kwargs)
    return wrapper

# --------------------------------------------------
# Base test case that stores extra details.
# --------------------------------------------------
class StyledTestCase(unittest.TestCase):
    def setUp(self):
        # Initialize a dictionary to store extra test info.
        # Also allow tests to set expected values as attributes.
        self._result_details = {}
        self.correct_solution = None
        self.reasoning_dict = {}

    def store_test_result(self, student_solution, correct_solution=None, reasoning_dict=None,
                          status='PASSED', error_type=None, error_message=None, error_traceback=None):
        # If no correct solution was passed, try to use the instance attribute,
        # or default to "Not provided" rather than None.
        if correct_solution is None:
            correct_solution = getattr(self, 'correct_solution', "Not provided")
        if reasoning_dict is None:
            reasoning_dict = getattr(self, 'reasoning_dict', {})
        self._result_details = {
            'student_solution': student_solution,
            'correct_solution': correct_solution,
            'reasoning_dict': reasoning_dict,
            'status': status,
            'error_type': error_type,
            'error_message': error_message,
            'error_traceback': error_traceback
        }

        
    def run(self, result=None):
        if result is None:
            result = self.defaultTestResult()
        result.startTest(self)
        testMethod = getattr(self, self._testMethodName)
        try:
            self.setUp()
            testMethod()
        except Exception as e:
            tb = ''.join(traceback.format_exception(*sys.exc_info()))
            # Note: self.correct_solution should have been set in setUp or the test method.
            self.store_test_result("Error in function",
                                  status='ERROR',
                                  error_type=type(e).__name__,
                                  error_message=str(e),
                                  error_traceback=tb)
            result.addError(self, sys.exc_info())
        else:
            result.addSuccess(self)
        finally:
            try:
                self.tearDown()
            except Exception as e:
                result.addError(self, sys.exc_info())
            result.stopTest(self)
        return result


# --------------------------------------------------
# Custom HTMLTestResult that builds detailed HTML output.
# --------------------------------------------------
class HTMLTestResult(unittest.TestResult):
    def __init__(self, stream=None, descriptions=True, verbosity=1):
        super().__init__(stream, descriptions, verbosity)
        self.results = []  # List to hold details for each test

    def startTest(self, test):
        super().startTest(test)
        if not hasattr(test, '_result_details'):
            test._result_details = {}

    def addSuccess(self, test):
        super().addSuccess(test)
        details = getattr(test, '_result_details', {})
        details['status'] = details.get('status', 'PASSED')
        self.results.append(details)

    def addFailure(self, test, err):
        super().addFailure(test, err)
        details = getattr(test, '_result_details', {})
        details['status'] = 'FAILED'
        details['error_type'] = type(err[1]).__name__
        details['error_message'] = str(err[1])
        details['error_traceback'] = ''.join(traceback.format_exception(*err))
        self.results.append(details)

    def addError(self, test, err):
        super().addError(test, err)
        details = getattr(test, '_result_details', {})
        details['status'] = 'ERROR'
        details['error_type'] = type(err[1]).__name__
        details['error_message'] = str(err[1])
        details['error_traceback'] = ''.join(traceback.format_exception(*err))
        self.results.append(details)

    def get_html_report(self):
        # Build the HTML report using inline CSS.
        output = ""
        for details in self.results:
            status = details.get('status', 'UNKNOWN')
            reasoning_dict = details.get('reasoning_dict', {})
            if status == 'ERROR':
                color = "#FF851B"  # Softer orange
                reasoning = reasoning_dict.get(details.get('error_type'),
                                                reasoning_dict.get('error', ''))
                reasoning += f"<br><strong>Error message:</strong> {html.escape(details.get('error_message',''))}"
                if details.get('error_traceback'):
                    formatted_tb = html.escape(details.get('error_traceback')).replace('\n', '<br>').replace(' ', '&nbsp;')
                    reasoning += f"<br><strong>Traceback:</strong><br><pre style='background-color: #f8f8f8; padding: 10px; border-radius: 5px;'>{formatted_tb}</pre>"
            elif status == 'FAILED':
                color = "#FF4136"  # Softer red
                reasoning = reasoning_dict.get('fail', '')
            elif status == 'PASSED':
                color = "#2ECC40"  # Softer green
                reasoning = reasoning_dict.get('pass', '')
            else:
                color = "#AAAAAA"  # Default gray
                reasoning = ""
            
            solutions_info = (
                f'<div style="margin-top: 5px;">'
                f'<strong>Your solution:</strong> {html.escape(str(details.get("student_solution", "")))}'
                f'</div>'
                f'<div style="margin-top: 2px;">'
                f'<strong>Correct solution:</strong> {html.escape(str(details.get("correct_solution", "")))}'
                f'</div>'
            )
            reasoning_info = ""
            if reasoning:
                reasoning_info = (
                    f'<div style="margin-top: 5px; color: {color};">'
                    f'<strong>Reasoning:</strong> {reasoning}'
                    f'</div>'
                )
            output += (
                f'<div style="font-family: \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif; '
                f'max-width: 600px; background-color: #FFFFFF; border: 1px solid #e0e0e0; '
                f'margin: 0; padding: 0; margin-bottom:10px;">'
                f'<div style="background-color: {color}; color: white; font-size: 16px; '
                f'font-weight: bold; padding: 5px 10px;">{status}</div>'
                f'<div style="padding: 10px;">{solutions_info}{reasoning_info}</div>'
                f'</div>'
            )
        return output

# --------------------------------------------------
# Custom HTMLTestRunner that uses HTMLTestResult.
# --------------------------------------------------
class HTMLTestRunner:
    def run(self, suite):
        result = HTMLTestResult()
        suite.run(result)
        return result.get_html_report()

# --------------------------------------------------
# Helper to run tests from the command line.
# --------------------------------------------------
def run_tests(test_class):
    if len(sys.argv) > 1:
        test_name = sys.argv[1]
        suite = unittest.TestSuite()
        suite.addTest(test_class(test_name))
    else:
        suite = unittest.TestLoader().loadTestsFromTestCase(test_class)
    runner = HTMLTestRunner()
    report = runner.run(suite)
    print(report)
